// Author: Vlad Nedelcu

import java.io.*;
import java.util.*;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class MyMain {
	
	public static void main (String[] args) throws IOException {
		CharStream input = CharStreams.fromFileName("input");
		TemaLexer lexer = new TemaLexer(input);

		CommonTokenStream tokenStream = null;
        TemaParser parser = null;
        ParserRuleContext globalTree = null;
		// Obtinem tokenii din input
        tokenStream = new CommonTokenStream(lexer);

        //TemaParser.MainContext ctx = getRuleContext;
        //System.out.println(ctx.getPayload());

        // Definim Parser-ul
        parser = new TemaParser(tokenStream);
        //TemaParser.MainContext result = $main::stack.get(0);
        

        // Incepem parsarea
        ParserRuleContext tree = parser.main();

        MainNode mm = TemaParser.MainContext.m;

        try {
			  BufferedWriter writer = new BufferedWriter(new FileWriter("arbore"));
			    writer.write(mm.show());
			    writer.close();
			}
			catch(IOException e) {
			  e.printStackTrace();
			}
	}
}