
import java.util.*;
import java.lang.Integer;

abstract class Expression extends Object{
	
	Expression parent;
	MainNode root;
	String offset = "";
	String name = "";
	String number = "";
	String bool = "";
	String symbol = "";
	int line = -1;


	abstract String show();
	abstract Expression interpret();

	public String addNewline(String print) {
		Scanner scanner = new Scanner(print);
		String build = "";
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			build += "\t" + line + "\n";
		}
		scanner.close();
		return build;
	}


	public void propagateOffset(Expression e, String offset){
		e.offset = offset;
		if(e instanceof Plus){
			((Plus)e).e1.propagateOffset(((Plus)e).e1,offset);
			((Plus)e).e2.propagateOffset(((Plus)e).e2,offset);
		}
		if(e instanceof Div){
			((Div)e).e1.propagateOffset(((Div)e).e1,offset);
			((Div)e).e2.propagateOffset(((Div)e).e2,offset);
		}
		if(e instanceof AritmPar){
			((AritmPar)e).e.propagateOffset(((AritmPar)e).e,offset);
		}
		if(e instanceof LogicPar){
			((LogicPar)e).e.propagateOffset(((LogicPar)e).e,offset);
		}
		if(e instanceof Not){
			((Not)e).e.propagateOffset(((Not)e).e,offset);
		}
		if(e instanceof Greater){
			((Greater)e).e1.propagateOffset(((Greater)e).e1,offset);
			((Greater)e).e2.propagateOffset(((Greater)e).e2,offset);
		}
		if(e instanceof And){
			((And)e).e1.propagateOffset(((And)e).e1,offset);
			((And)e).e2.propagateOffset(((And)e).e2,offset);
		}
		if(e instanceof Assign){
			((Assign)e).v.propagateOffset(((Assign)e).v,offset);
			((Assign)e).e.propagateOffset(((Assign)e).e,offset);
		}

	}

	// trimite root-ul (MainNode) in tot arborele
	public void propagateParent(Expression e){
		if(e instanceof Plus){
			((Plus)e).e1.root = this.root;
			((Plus)e).e2.root = this.root;
			((Plus)e).e1.propagateParent(((Plus)e).e1);
			((Plus)e).e2.propagateParent(((Plus)e).e2);
		}
		if(e instanceof Div){
			((Div)e).e1.root = this.root;
			((Div)e).e2.root = this.root;
			((Div)e).e1.propagateParent(((Div)e).e1);
			((Div)e).e2.propagateParent(((Div)e).e2);
		}
		if(e instanceof AritmPar){
			((AritmPar)e).e.root = this.root;
			((AritmPar)e).e.propagateParent(((AritmPar)e).e);
		}
		if(e instanceof LogicPar){
			((LogicPar)e).e.root = this.root;
			((LogicPar)e).e.propagateParent(((LogicPar)e).e);
		}
		if(e instanceof Not){
			((Not)e).e.root = this.root;
			((Not)e).e.propagateParent(((Not)e).e);
		}
		if(e instanceof Greater){
			((Greater)e).e1.root = this.root;
			((Greater)e).e2.root = this.root;
			((Greater)e).e1.propagateParent(((Greater)e).e1);
			((Greater)e).e2.propagateParent(((Greater)e).e2);
		}
		if(e instanceof And){

			((And)e).e1.root = this.root;
			((And)e).e2.root = this.root;
			((And)e).e1.propagateParent(((And)e).e1);
			((And)e).e2.propagateParent(((And)e).e2);
		}
		if(e instanceof Assign){
			((Assign)e).v.root = this.root;
			((Assign)e).e.root = this.root;
			((Assign)e).v.propagateParent(((Assign)e).v);
			((Assign)e).e.propagateParent(((Assign)e).e);
		}
		if(e instanceof StmtList){
			for (Expression el : ((StmtList)e).elems) {
				el.parent = this;
				el.root = this.root;
				el.propagateParent(el);
			}
		}

	}
};

// orice expresie cu mai mult de 2 copii este/extinde tipul Stmtlist
class StmtList extends Expression {
	LinkedList<Expression> elems = new LinkedList<>();
	
	public StmtList(ArrayList<Expression> elems, String offset) {
		super();
		LinkedList<Expression> l = new LinkedList<>(elems);
		this.elems = l;
		this.offset = offset;
	}

	@Override
	public String show() {
		String build = "";

		build += "<SequenceNode>\n";
		
		String print = "";
		for (Expression e : elems) {
				propagateOffset(e,offset);
				print += offset;
				print += e.show();
		}
		
		build += addNewline(print); 
		
		return build;
	}

	@Override
	public Expression interpret() {
		return this;
	}

	public void ajustSequenceList(){
		if(elems.size() > 1)
			if(elems.peek() instanceof StmtList) {
				StmtList last = (StmtList)elems.pollLast();
				StmtList first = (StmtList)elems.pollLast();
				last.elems.peek().offset = first.elems.peek().offset;
				first.elems.add(last.elems.pop());
				elems.add(first);
			}
			
		if(elems.size() == 1) {
			if(elems.peek() instanceof SequenceNode) {
				StmtList st = (SequenceNode)elems.pop();
				if(st.elems.size() == 1)
					elems.push(st.elems.pop());
				else
					elems.push(st);
			}
		}
		
		if(this instanceof Block ) {
			if(elems.peek() instanceof StmtList) {
				StmtList st = (StmtList)elems.peek();
				if(st.elems.size() <= 1){
					elems.pop();
					elems.push(st.elems.pop());
				}
					
			}
		}
	}
};

// copii lui MainNode si WhileBlock sunt de tipul SequenceNode
class SequenceNode extends StmtList {
	
	public SequenceNode(ArrayList<Expression> elems, String offset) {
		super(elems,offset);
	}

	@Override
	public String show() {
		String build = "";
		build += offset + "<SequenceNode>\n";
		
		String print = "";
		for (Expression e : elems) {
				print += offset;
				print += e.show();
		}
		
		build += addNewline(print); 
		
		return build;
	}
};

// radacina arborelui sintactic
class MainNode extends StmtList {
	HashMap<String,Integer> idTable;

	public MainNode(ArrayList<Expression> elems, String offset) {
		super(elems,offset);
	}
	@Override
	public String show() {
		this.ajustSequenceList();
		String build = "";
		build += "<MainNode>\n";
		
		String print = "";
		for (Expression e : elems) {
				print += e.show();
		}
		build += addNewline(print); 
		return build;
	}

	@Override
	public Expression interpret() {
		return this; 
	}
	
}

// block din interiorul unui If sau While
class Block extends StmtList {

	public Block(ArrayList<Expression> elems, String offset) {
		super(elems,offset);
	}
	@Override
	public String show() {
		this.ajustSequenceList();
		String build = "";
		build += "<BlockNode> {}\n";
		
		String print = "";
		
		for (Expression e : elems) {
				e.propagateOffset(e,offset);
				print += offset + e.show();
		}
		
		build += addNewline(print); 
		
		return build;
	}
	
}

class Number extends Expression {

	public Number(String number) {
		super();
		this.number = number;
	}

	@Override
	public String show() {
		return "<IntNode> " + number + "\n";
	}

	@Override
	public Expression interpret() {
		return this;
	}
	
};

class Boolean extends Expression {

	public Boolean(String bool) {
		super();
		this.bool = bool;
	}

	@Override
	public String show() {
		return "<BoolNode> " + bool + "\n";
	}

	@Override
	public Expression interpret() {
		return this;
	}
};

class Variable extends Expression {

	public Variable(String name) {
		super();
		this.name = name;
	}

	@Override
	public String show() {
		return "<VariableNode> " + name + "\n";
	}

	@Override
	public Expression interpret() {
		return this;
	}
	
};

class AritmPar extends Expression {

	Expression e;

	public AritmPar(Expression e) {
		super();
		this.e = e;
		e.offset = offset;
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<BracketNode> ()\n";
		
		String print = "";
		print += offset + e.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
};

class LogicPar extends Expression {

	Expression e;

	public LogicPar(Expression e) {
		super();
		this.e = e;
		propagateOffset(e,offset);
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<BracketNode> ()\n";
		
		String print = "";
		print += offset + e.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
};

class IfBlock extends StmtList {

	public IfBlock(ArrayList<Expression> elems, String offset) {
		super(elems,offset);
	}
	@Override
	public String show() {
		String build = "";
		build += "<IfNode> if\n";
		String print = "";
		
		for (Expression e : elems) {
				propagateOffset(e,offset);
				print += offset + e.show();
		}
		
		build += addNewline(print); 
		
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
};

class WhileBlock extends StmtList {

	public WhileBlock(ArrayList<Expression> elems, String offset) {
			super(elems,offset);
		}
	@Override
	public String show() {

		String build = "";
		build += "<WhileNode> while\n";
		
		String print = "";
		
		for (Expression e : elems) {
				propagateOffset(e,offset);
				print += offset + e.show();
		}
		
		build += addNewline(print); 
		
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
};

// folosit pentru operatori +,>,/,&&,! si paranteze (,),{,}
class Symbol extends Expression {

	public Symbol(String symbol) {
		super();
		this.symbol = symbol;
	}
	
	String symbol() {
		return symbol;
	}

	@Override
	public String show() {
		return null;
	}

	@Override
	public Expression interpret() {
		return null;
	}
	
};

// nod AssignmentNode
class Assign extends Expression {
	Variable v;
	Expression e;

	public Assign(Variable v, Expression e, String offset) {
		super();
		this.v = v;
		this.e = e;
		this.offset = offset;
	}
	@Override
	public String show() {
		String build = "";
		build += "<AssignmentNode> =\n";
		
		String print = "";
		v.offset = offset;
		e.offset = offset;
		print += offset + v.show() + offset + e.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return null;
	} 
	
};

class Plus extends Expression {
	Expression e1, e2;

	public Plus(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<PlusNode> +\n";
		
		String print = "";
		print += offset + e1.show() + offset + e2.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
}; 

class Not extends Expression {
	Expression e;

	public Not(Expression e) {
		super();
		this.e = e;
		this.bool = e.bool;
		this.root = e.root;
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<NotNode> !\n";
		
		String print = "";
		print += offset + e.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
}; 

class Div extends Expression {
	Expression e1, e2;

	public Div(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<DivNode> /\n";
		
		String print = "";
		print += offset + e1.show() + offset + e2.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
}; 

class Greater extends Expression {
	Expression e1, e2;

	public Greater(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<GreaterNode> >\n";
		
		String print = "";
		print += offset + e1.show() + offset + e2.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
}; 

class And extends Expression {
	Expression e1, e2;

	public And(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}
	@Override
	public String show() {
		propagateOffset(this,offset);
		String build = "";
		build += "<AndNode> &&\n";
		
		String print = "";
		print += offset + e1.show() + offset + e2.show();
		
		build += addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		return this;
	}
}; 


