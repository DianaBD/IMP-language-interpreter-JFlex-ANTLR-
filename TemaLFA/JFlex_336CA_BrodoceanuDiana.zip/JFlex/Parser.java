// Author: Vlad Nedelcu

import java.io.*;
import java.util.*;

public class Parser {
	public static String addNewline(String print) {
		Scanner scanner = new Scanner(print);
		String build = "";
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			build += "\t" + line + "\n";
		}
		scanner.close();
		return build;
	}
	
	public static void main (String[] args) throws IOException {
		HelloLexer l = new HelloLexer(new FileReader("input"));
		l.yylex();

		try {
		  BufferedWriter writer = new BufferedWriter(new FileWriter("arbore"));
		    writer.write(((StmtList) l.stack.peek()).show());
		    writer.close();
		}
		catch(IOException e) {
		  e.printStackTrace();
		}
		
		MainNode m = ((MainNode) l.stack.peek());
		m.interpret();
		System.out.println("     in Main UnassignedVar " + m.error_unassigned_var);
		System.out.println("     in Main m.error_div_by_zero = " + m.error_div_by_zero);
		try {
	      BufferedWriter writer = new BufferedWriter(new FileWriter("output"));
	      if(m.error_unassigned_var > 0)
	        writer.write("UnassignedVar " + m.error_unassigned_var +"\n");
	      else{
	      	if(m.error_div_by_zero > 0){
	      		System.out.println("     in Main m.error_div_by_zero = " + m.error_div_by_zero);
	            writer.write("DivideByZero " + m.error_div_by_zero +"\n");
	        }
	        else{
	        	
	        	String varString = "";
			    Iterator it = m.idTable.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        varString += pair.getKey() + "=" + pair.getValue() + "\n";
			    }
			    writer.write(varString);
	        }
	      }     
	      writer.close();
	    }
	    catch(IOException e) {
	      e.printStackTrace();
	    }

	}
}