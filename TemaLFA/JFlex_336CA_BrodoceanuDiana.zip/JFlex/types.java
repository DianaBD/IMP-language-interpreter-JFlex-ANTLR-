
import java.util.*;
import java.lang.Integer;

abstract class Expression extends Object{
	
	Expression parent;
	MainNode root;
	String name = "";
	String number = "";
	String bool = "";
	String symbol = "";
	int line = -1;


	abstract String show();
	abstract Expression interpret();

	// intoarce valoare numerica a expresiei
	int getValue(Expression e){
        if (e instanceof Number || e instanceof Plus || e instanceof Div || e instanceof AritmPar) {
            if(!e.number.equals(""))
            	return Integer.parseInt(e.number);
            else
            	return -1;
        }
        if (e instanceof Variable) {
            if(e.root.idTable.containsKey(e.name)){
	            if(e.root.idTable.get(e.name) != null)
	                return e.root.idTable.get(e.name);
	            else{
	            	root.error_unassigned_var = e.line + 1;
	            	return -1;
	            }
	        }
            else{
                return -1;
            }
                
        }
        return -1;
    }

    // intoarce valoarea booleana a expresiei
    boolean getBoolValue(Expression e){
        if(e.bool.equals("true"))
            return true;
        else
            return false;
    }

	// trimite root-ul (MainNode) in tot arborele
	public void propagateParent(Expression e){
		if(e instanceof Plus){
			((Plus)e).e1.root = this.root;
			((Plus)e).e2.root = this.root;
			((Plus)e).e1.propagateParent(((Plus)e).e1);
			((Plus)e).e2.propagateParent(((Plus)e).e2);
		}
		if(e instanceof Div){
			((Div)e).e1.root = this.root;
			((Div)e).e2.root = this.root;
			((Div)e).e1.propagateParent(((Div)e).e1);
			((Div)e).e2.propagateParent(((Div)e).e2);
		}
		if(e instanceof AritmPar){
			((AritmPar)e).e.root = this.root;
			((AritmPar)e).e.propagateParent(((AritmPar)e).e);
		}
		if(e instanceof LogicPar){
			((LogicPar)e).e.root = this.root;
			((LogicPar)e).e.propagateParent(((LogicPar)e).e);
		}
		if(e instanceof Not){
			((Not)e).e.root = this.root;
			((Not)e).e.propagateParent(((Not)e).e);
		}
		if(e instanceof Greater){
			((Greater)e).e1.root = this.root;
			((Greater)e).e2.root = this.root;
			((Greater)e).e1.propagateParent(((Greater)e).e1);
			((Greater)e).e2.propagateParent(((Greater)e).e2);
		}
		if(e instanceof And){

			((And)e).e1.root = this.root;
			((And)e).e2.root = this.root;
			((And)e).e1.propagateParent(((And)e).e1);
			((And)e).e2.propagateParent(((And)e).e2);
		}
		if(e instanceof Assign){
			((Assign)e).v.root = this.root;
			((Assign)e).e.root = this.root;
			((Assign)e).v.propagateParent(((Assign)e).v);
			((Assign)e).e.propagateParent(((Assign)e).e);
		}
		if(e instanceof StmtList){
			for (Expression el : ((StmtList)e).elems) {
				el.parent = this;
				el.root = this.root;
				el.propagateParent(el);
			}
		}

	}
};

// orice expresie cu mai mult de 2 copii este/extinde tipul Stmtlist
class StmtList extends Expression {
	LinkedList<Expression> elems = new LinkedList<>();
	
	public StmtList(LinkedList<Expression> elems) {
		super();
		this.elems = elems;
	}

	@Override
	public String show() {
		String build = "";
		this.ajustSequenceList();
		build += "<SequenceNode>\n";
		String print = "";
		for (Expression e : elems) {
				print += e.show();
		}
		
		build += Parser.addNewline(print); 
		
		return build;
	}

	@Override
	public Expression interpret() {
		
		LinkedList<Expression> newls = new LinkedList<Expression>();
		for (Expression e : elems) {
			Expression ex = e.interpret();
			if(ex instanceof Myerror)
				return new Myerror();
			newls.add(ex);
		}
		return new StmtList(newls);
	}

	public void ajustSequenceList(){

		for (int i = 0; i < elems.size(); i++) {
			if(elems.get(i) instanceof StmtList)
				((StmtList)elems.get(i)).ajustSequenceList();
		}


		// ultimele 2 elemente ale ultimului stmt => 1 stmt cu 2 copii
		//System.out.println("pentru " + this + " inainte:  " + elems);
		if(elems.size() > 1){
			int n = elems.size() - 1;
			if(elems.get(n) instanceof SequenceNode && elems.get(n-1) instanceof SequenceNode) {
				StmtList last = (StmtList)elems.pollLast();
				StmtList first = (StmtList)elems.pollLast();
				//System.out.println("\naranjeaza ultimele 2 -> last  " + last.show() + "\n");
				//System.out.println("\naranjeaza ultimele 2 -> first " + first.show() + "\n");

				first.elems.add(last.elems.pop());
				elems.add(first);
			}
		}
		// 1 stmt cu 1 copil => doar copil
		//System.out.println("pentru " + this + " dupa1:  " + elems); 
		if(elems.size() == 1) {
			if(elems.peek() instanceof SequenceNode) {
				StmtList st = (SequenceNode)elems.pop();

				if(st.elems.size() == 1){
					//System.out.println("\nscoate SequenceNode  " + st.elems.get(0).show() + "\n");
					elems.push(st.elems.pop());
				}
					
				else
					elems.push(st);
			}
		}
		//System.out.println("pentru " + this + " dupa2:  " + elems); 
		/*
		if(this instanceof Block ) {
			if(elems.peek() instanceof StmtList) {
				StmtList st = (StmtList)elems.peek();
				if(st.elems.size() <= 1){
					elems.pop();
					elems.push(st.elems.pop());
				}
			}
		}*/

		if(this instanceof Block || this instanceof MainNode) {
			//System.out.println(elems);
			Collections.reverse(elems);
			while(elems.size() >= 2 && elems.get(1) instanceof StmtList) {
			
				Expression child = elems.pop();
				StmtList parent = (StmtList)elems.pop();
				parent.elems.add(child);
				//System.out.println(child.show());
				//System.out.println(parent.show());
				elems.push(parent);
			}
			Collections.reverse(elems);
		}
		//System.out.println("pentru " + this + " dupa3:  " + elems + '\n'); 
	}
};

// copii lui MainNode si WhileBlock sunt de tipul SequenceNode
class SequenceNode extends StmtList {
	
	public SequenceNode(LinkedList<Expression> elems) {
		super(elems);
	}

	@Override
	public String show() {
		String build = "";
		
		build += "<SequenceNode>\n";
		
		String print = "";

		/*
		for (int i = 0; i < elems.size(); i++) {
			if(elems.get(i) instanceof SequenceNode)
				((SequenceNode)elems.get(i)).ajustSequenceList();
		}
		this.ajustSequenceList();
		*/
		for (Expression e : elems) {
				print += e.show();
		}
		
		build += Parser.addNewline(print); 
		
		return build;
	}
};

// radacina arborelui sintactic
class MainNode extends StmtList {
	HashMap<String,Integer> idTable;
	int error_unassigned_var = 0;
	int error_div_by_zero = 0;

	public MainNode(LinkedList<Expression> elems, HashMap<String,Integer> idTable, int error_unassigned_var,int error_div_by_zero) {
		super(elems);
		this.root = this;
		this.idTable = idTable;
		this.error_unassigned_var = error_unassigned_var;
		this.error_div_by_zero = error_div_by_zero;
	}
	@Override
	public String show() {
		
		String build = "";
		build += "<MainNode>\n";
		/*
		for (int i = 0; i < elems.size(); i++) {
			if(elems.get(i) instanceof SequenceNode)
				((SequenceNode)elems.get(i)).ajustSequenceList();
		}*/
		this.ajustSequenceList();

		String print = "";
		for (Expression e : elems) {
				print += e.show();
		}
		build += Parser.addNewline(print); 
		return build;
	}

	@Override
	public Expression interpret() {
		if(error_unassigned_var > 0){
			return this;
		}
		this.propagateParent(this);

		LinkedList<Expression> newls = new LinkedList<Expression>();
		for (Expression e : elems) {

			Expression ex = e.interpret();
			if(ex instanceof Myerror){
				return this;
			}
			newls.add(ex);
		}

		return new MainNode(newls,this.idTable, error_unassigned_var, error_div_by_zero);
	}
	
}

// block din interiorul unui If sau While
class Block extends StmtList {

	public Block(LinkedList<Expression> elems) {
		super(elems);
	}
	@Override
	public String show() {
		//this.ajustSequenceList();
		String build = "";
		build += "<BlockNode> {}\n";
		
		String print = "";
		/*
		for (int i = 0; i < elems.size(); i++) {
			if(elems.get(i) instanceof SequenceNode)
				((SequenceNode)elems.get(i)).ajustSequenceList();
		}
		this.ajustSequenceList();*/

		for (Expression e : elems) {
				print += e.show();
		}
		
		build += Parser.addNewline(print); 
		
		return build;
	}
	
}

class Number extends Expression {

	public Number(String number, int line, MainNode root) {
		super();
		this.number = number;
		this.line = line;
		this.root = root;
	}

	@Override
	public String show() {
		return "<IntNode> " + number + "\n";

	}

	@Override
	public Expression interpret() {
		return this;
	}
	
};

class Boolean extends Expression {

	public Boolean(String bool) {
		super();
		this.bool = bool;
	}

	@Override
	public String show() {
		return "<BoolNode> " + bool + "\n";
	}

	@Override
	public Expression interpret() {
		return this;
	}
};

class Variable extends Expression {

	public Variable(String name, int line, MainNode root) {
		super();
		this.name = name;
		this.line = line;
		this.root = root;

		if(!root.idTable.containsKey(name)){
			this.root.error_unassigned_var = line;
		}
	}

	@Override
	public String show() {
		return "<VariableNode> " + name + "\n";
	}

	@Override
	public Expression interpret() {
		if(!root.idTable.containsKey(name)){
			return new Myerror();
		}
		return this;
	}
	
};

class AritmPar extends Expression {

	Expression e;

	public AritmPar(Expression e) {
		super();
		this.e = e;
		this.line = e.line;
		this.root = e.root;
	}
	@Override
	public String show() {
		String build = "";
		build += "<BracketNode> ()\n";
		
		String print = "";
		print += e.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e.interpret() instanceof Myerror)
			return new Myerror();
		e = e.interpret();
		this.number = e.number;
		return this;
	}
};

class LogicPar extends Expression {

	Expression e;

	public LogicPar(Expression e) {
		super();
		this.e = e;
	}
	@Override
	public String show() {
		String build = "";
		build += "<BracketNode> ()\n";
		
		String print = "";
		print += e.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e.interpret() instanceof Myerror)
			return new Myerror();
		e = e.interpret();
		this.bool = e.bool;
		return this;
	}
};

class IfBlock extends StmtList {

	public IfBlock(LinkedList<Expression> elems) {
		super(elems);
	}
	@Override
	public String show() {
		String build = "";
		build += "<IfNode> if\n";
		String print = "";
		
		for (Expression e : elems) {
				print += e.show();
		}
		
		build += Parser.addNewline(print); 
		
		return build;
	}
	@Override
	public Expression interpret() {
		Expression cond_par = elems.get(0);
		Block ibl = (Block)elems.get(1);
		Block ebl = (Block)elems.get(2);

		if(cond_par.interpret() instanceof Myerror)
			return new Myerror();
		boolean cond_value = getBoolValue(cond_par.interpret());
		if(cond_value == true) {
			if(ibl.interpret() instanceof Myerror)
				return new Myerror();
		}
		else
			if(ebl.interpret() instanceof Myerror)
				return new Myerror();
		return this;
	}
};

class WhileBlock extends StmtList {

	public WhileBlock(LinkedList<Expression> elems) {
			super(elems);
		}
	@Override
	public String show() {

		String build = "";
		build += "<WhileNode> while\n";
		
		String print = "";
		
		for (Expression e : elems) {
				print += e.show();
		}
		
		build += Parser.addNewline(print); 
		
		return build;
	}
	@Override
	public Expression interpret() {
		Expression cond_par = elems.get(0);
		Block wbl = (Block)elems.get(1);

		if(cond_par.interpret() instanceof Myerror)
			return new Myerror();
		boolean cond_value = getBoolValue(cond_par.interpret());
		while(cond_value == true){
			if(wbl.interpret() instanceof Myerror)
				return new Myerror();
			cond_value = getBoolValue(cond_par.interpret());
		}
		return this;
	}
};

// folosit pentru operatori +,>,/,&&,! si paranteze (,),{,}
class Symbol extends Expression {

	public Symbol(String symbol) {
		super();
		this.symbol = symbol;
	}
	
	String symbol() {
		return symbol;
	}

	@Override
	public String show() {
		return null;
	}

	@Override
	public Expression interpret() {
		return null;
	}
	
};

// nod AssignmentNode
class Assign extends Expression {
	Variable v;
	Expression e;

	public Assign(Variable v, Expression e, MainNode root) {
		super();
		this.v = v;
		this.e = e;
		this.root = root;
		if(e.interpret().number.equals(""))
			root.error_unassigned_var = v.line + 1;
		else
			root.idTable.put(v.name,getValue(e.interpret()));

	}
	@Override
	public String show() {
		String build = "";
		build += "<AssignmentNode> =\n";
		
		String print = "";
		print += v.show() + e.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(v.interpret() instanceof Myerror || e.interpret() instanceof Myerror)
			return new Myerror();
		e = e.interpret();
		root.idTable.put(v.name,getValue(e));
		return this;
	} 
	
};

class Plus extends Expression {
	Expression e1, e2;

	public Plus(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
		this.line = e1.line;
		this.root = e1.root;
	}
	@Override
	public String show() {
		String build = "";
		build += "<PlusNode> +\n";
		
		String print = "";
		print += e1.show() + e2.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e1.interpret() instanceof Myerror || e2.interpret() instanceof Myerror)
			return new Myerror();

		if(e1 instanceof Variable)
			if(root.idTable.get(e1.name) == null){
				root.error_unassigned_var = e1.line + 1;
				return new Myerror();
			}
				

		if(e2 instanceof Variable)
			if(root.idTable.get(e2.name) == null){
				root.error_unassigned_var = e2.line + 1;
				return new Myerror();
			}

		int value1, value2;

        value1 = getValue(e1.interpret());
        value2 = getValue(e2.interpret());

        int rez = value1 + value2;
        if(rez != -1)
        	this.number = "" + rez;
		return this;
	}
}; 

class Not extends Expression {
	Expression e;

	public Not(Expression e) {
		super();
		this.e = e;
		this.bool = e.bool;
		this.root = e.root;
	}
	@Override
	public String show() {
		String build = "";
		build += "<NotNode> !\n";
		
		String print = "";
		print += e.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e.interpret() instanceof Myerror)
			return new Myerror();
               
        if(e.interpret().bool.equals("true"))
            e.bool = "false";
        else
            e.bool = "true";
        this.bool = e.bool;
		return this;
	}
}; 

class Div extends Expression {
	Expression e1, e2;

	public Div(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
		this.root = e1.root;
	}
	@Override
	public String show() {
		String build = "";
		build += "<DivNode> /\n";
		
		String print = "";
		print += e1.show() + e2.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e1.interpret() instanceof Myerror || e2.interpret() instanceof Myerror)
			return new Myerror();

		if(e1 instanceof Variable)
			if(root.idTable.get(e1.name) == null){
				root.error_unassigned_var = e1.line + 1;
				return new Myerror();
			}
				

		if(e2 instanceof Variable)
			if(root.idTable.get(e2.name) == null){
				root.error_unassigned_var = e2.line + 1;
				return new Myerror();
			}
				

		int value1, value2;

        value1 = getValue(e1.interpret());
        value2 = getValue(e2.interpret());

        int rez = -1;
        if(value2 == 0){
            root.error_div_by_zero = e2.line + 1;
            return new Myerror();
        }
        else
            rez = value1 / value2;
        this.number = "" + rez;

		return this;
	}
}; 

class Greater extends Expression {
	Expression e1, e2;

	public Greater(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}
	@Override
	public String show() {
		String build = "";
		build += "<GreaterNode> >\n";
		
		String print = "";
		print += e1.show() + e2.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e1.interpret() instanceof Myerror || e2.interpret() instanceof Myerror)
			return new Myerror();

		int value1, value2;
        value1 = getValue(e1.interpret());
        value2 = getValue(e2.interpret());

        boolean rez = value1 > value2;
        this.bool = "" + rez;
		return this;
	}
}; 

class And extends Expression {
	Expression e1, e2;

	public And(Expression e1, Expression e2) {
		super();
		this.e1 = e1;
		this.e2 = e2;
	}
	@Override
	public String show() {
		String build = "";
		build += "<AndNode> &&\n";
		
		String print = "";
		print += e1.show() + e2.show();
		
		build += Parser.addNewline(print); 
		return build;
	}
	@Override
	public Expression interpret() {
		if(e1.interpret() instanceof Myerror || e2.interpret() instanceof Myerror)
			return new Myerror();

		boolean value1, value2;

        value1 = getBoolValue(e1.interpret());
        value2 = getBoolValue(e2.interpret());

        boolean rez = value1 && value2;
        this.bool = "" + rez;
		return this;
	}
}; 

class Myerror extends Expression {
	@Override
	public String show() {
		return "error";
	}
	@Override
	public Expression interpret() {
		return this;
	}
}

